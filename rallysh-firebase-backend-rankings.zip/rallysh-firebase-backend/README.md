# Rallysh rating approval backend

This trusted Cloud Function applies rating and match-count changes to both teams only after the invited opponent approves the score.

1. From this folder, run `firebase login`.
2. Run `cd functions`, then `npm install`, then `cd ..`.
3. Run `firebase deploy --only functions,firestore,storage`.
4. Deploy the latest web `index.html` to your GitHub Pages or Firebase Hosting site.

The Firebase project must be on Blaze for Cloud Functions.
