# Rallysh iOS wrapper

This Xcode project is an iPhone wrapper for the live Rallysh web app. It uses a native `WKWebView`, native iOS sharing, and iOS permission prompts for photos, camera, and location.

## Before opening

1. On your Mac, copy this entire `rallysh-ios` folder somewhere convenient.
2. In Firebase Console, create an iOS app with bundle ID `com.lyttech.rallysh`.
3. Download `GoogleService-Info.plist`. The current wrapper loads the existing web Firebase app, so the file is not required to compile; add it later only when native Firebase or native Google Sign-In is added.
4. Open `Rallysh.xcodeproj` in Xcode.

## Configure signing

Select **Rallysh** under **Targets** > **Signing & Capabilities**:

- Turn on **Automatically manage signing**.
- Select your Apple Developer team.
- Confirm the Bundle Identifier is `com.lyttech.rallysh`.

## Update the web address

`RallyshConfig.swift` contains the web app address. It is currently set to:

`https://gauravsigmano1.github.io/Ace-Rank-Codex/`

For production, change it to your Firebase Hosting URL after hosting is set up.

## App icon

Before uploading to App Store Connect, replace `Assets.xcassets/AppIcon.appiconset` with a complete Apple App Icon set, including a 1024x1024 PNG. Xcode's Assets catalog can generate the required sizes from that image.

## Test

Connect an iPhone, select it as the Xcode run destination, then press Run.

The wrapper asks for location only after the web app requests it. Camera and photo permission descriptions are included in `Info.plist`, and photo selection works through the web view's standard file picker.

## Archive

Set Version and Build in the target's General tab, then select **Product > Archive**. In Organizer, choose **Distribute App > App Store Connect > Upload**.

> Google sign-in is currently web-based. Before App Store launch, test it on a physical iPhone. If Google rejects WebView OAuth, replace that route with native Google Sign-In for iOS.
