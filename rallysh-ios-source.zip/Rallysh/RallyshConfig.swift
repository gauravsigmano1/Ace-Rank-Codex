import Foundation

enum RallyshConfig {
    // Change this to your Firebase Hosting URL before the production release.
    static let appURL = URL(string: "https://gauravsigmano1.github.io/Ace-Rank-Codex/")!
}
