import UIKit
import WebKit
import SafariServices
import CoreLocation

final class RallyshWebViewController: UIViewController {
    private let locationManager = CLLocationManager()
    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        locationManager.delegate = self

        let contentController = WKUserContentController()
        contentController.add(self, name: "rallyshShare")
        contentController.add(self, name: "rallyshLocation")
        contentController.addUserScript(WKUserScript(
            source: """
            (function () {
              if (!window.webkit || !window.webkit.messageHandlers) return;
              var originalShare = navigator.share ? navigator.share.bind(navigator) : null;
              navigator.share = function (data) {
                try {
                  window.webkit.messageHandlers.rallyshShare.postMessage({
                    title: data && data.title ? String(data.title) : 'Rallysh',
                    text: data && data.text ? String(data.text) : '',
                    url: data && data.url ? String(data.url) : ''
                  });
                  return Promise.resolve();
                } catch (error) {
                  return originalShare ? originalShare(data) : Promise.reject(error);
                }
              };
              if (navigator.geolocation) {
                var originalGetCurrentPosition = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
                navigator.geolocation.getCurrentPosition = function (success, failure, options) {
                  window.__rallyshLocationSuccess = success;
                  window.__rallyshLocationFailure = failure;
                  window.webkit.messageHandlers.rallyshLocation.postMessage({});
                };
                window.__rallyshOriginalGetCurrentPosition = originalGetCurrentPosition;
              }
            })();
            """,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        ))

        let configuration = WKWebViewConfiguration()
        configuration.userContentController = contentController
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = true
        configuration.allowsInlineMediaPlayback = true

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        webView.load(URLRequest(url: RallyshConfig.appURL))
    }

    private func presentShare(title: String, text: String, url: String) {
        var items: [Any] = [text]
        if let shareURL = URL(string: url), !url.isEmpty { items.append(shareURL) }
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        controller.popoverPresentationController?.sourceView = view
        present(controller, animated: true)
    }

    private func requestLocation() {
        switch locationManager.authorizationStatus {
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .authorizedAlways, .authorizedWhenInUse:
            locationManager.requestLocation()
        default:
            sendLocationError("Location permission was not granted.")
        }
    }

    private func sendLocation(_ location: CLLocation) {
        let javascript = "window.__rallyshLocationSuccess && window.__rallyshLocationSuccess({coords:{latitude:\(location.coordinate.latitude),longitude:\(location.coordinate.longitude),accuracy:\(location.horizontalAccuracy)},timestamp:\(location.timestamp.timeIntervalSince1970 * 1000)});"
        webView.evaluateJavaScript(javascript)
    }

    private func sendLocationError(_ message: String) {
        let escaped = message.replacingOccurrences(of: "'", with: "\\'")
        webView.evaluateJavaScript("window.__rallyshLocationFailure && window.__rallyshLocationFailure({code:1,message:'\(escaped)'});")
    }
}

extension RallyshWebViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "rallyshShare":
            let payload = message.body as? [String: Any]
            presentShare(
                title: payload?["title"] as? String ?? "Rallysh",
                text: payload?["text"] as? String ?? "",
                url: payload?["url"] as? String ?? ""
            )
        case "rallyshLocation": requestLocation()
        default: break
        }
    }
}

extension RallyshWebViewController: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedAlways || manager.authorizationStatus == .authorizedWhenInUse {
            manager.requestLocation()
        } else if manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted {
            sendLocationError("Location permission was not granted.")
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last { sendLocation(location) }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        sendLocationError(error.localizedDescription)
    }
}

extension RallyshWebViewController: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if ["tel", "mailto"].contains(url.scheme?.lowercased() ?? "") {
            UIApplication.shared.open(url)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { present(SFSafariViewController(url: url), animated: true) }
        return nil
    }

    @available(iOS 15.0, *)
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.prompt)
    }
}
