const {onCall, HttpsError} = require('firebase-functions/v2/https');
const admin = require('firebase-admin');

admin.initializeApp();
const db = admin.firestore();

exports.approveMatch = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in before approving a score.');
  const approvalId = request.data?.approvalId;
  if (!approvalId || typeof approvalId !== 'string') throw new HttpsError('invalid-argument', 'A valid approval ID is required.');

  const approvalRef = db.collection('approvals').doc(approvalId);
  const postRef = db.collection('posts').doc(approvalId);
  await db.runTransaction(async (tx) => {
    const approvalSnap = await tx.get(approvalRef);
    if (!approvalSnap.exists) throw new HttpsError('not-found', 'Approval request not found.');
    const approval = approvalSnap.data();
    if (approval.status !== 'pending') throw new HttpsError('failed-precondition', 'This score was already processed.');
    if ((request.auth.token.email || '').toLowerCase() !== (approval.opponentEmail || '').toLowerCase()) {
      throw new HttpsError('permission-denied', 'Only the invited opponent can approve this score.');
    }

    const ratingField = approval.key === 'doubles' ? 'doubles' : 'singles';
    const matchesField = approval.key === 'doubles' ? 'dm' : 'sm';
    const teamA = Array.isArray(approval.playersA) ? approval.playersA : [approval.authorUid];
    const teamB = Array.isArray(approval.playersB) ? approval.playersB : [];
    if (!teamA.length || !teamB.length || !Number.isFinite(approval.delta)) {
      throw new HttpsError('failed-precondition', 'This match is missing rating data.');
    }

    const teamADelta = Number(approval.delta);
    const teamBDelta = -(teamADelta * teamA.length / teamB.length);
    for (const userId of teamA) {
      tx.update(db.collection('users').doc(userId), {
        [ratingField]: admin.firestore.FieldValue.increment(teamADelta),
        [matchesField]: admin.firestore.FieldValue.increment(1)
      });
    }
    for (const userId of teamB) {
      tx.update(db.collection('users').doc(userId), {
        [ratingField]: admin.firestore.FieldValue.increment(teamBDelta),
        [matchesField]: admin.firestore.FieldValue.increment(1)
      });
    }
    tx.update(approvalRef, {status: 'approved', approvedBy: request.auth.uid, approvedAt: admin.firestore.FieldValue.serverTimestamp()});
    tx.update(postRef, {pending: false});
  });
  return {ok: true};
});
