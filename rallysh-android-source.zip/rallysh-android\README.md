# Rallysh Android wrapper

1. Open this folder in Android Studio (latest stable release).
2. Let Android Studio install the requested Android SDK 36 and Gradle dependencies.
3. Select **Build > Generate Signed Bundle / APK**.
4. Choose **Android App Bundle**, create or select an upload key, and select the `release` build variant.
5. The upload file will be created at `app/release/app-release.aab`.

Use the resulting `.aab` in Google Play Console. Keep the upload key secure; use the same key for all future updates.
