# Publish Rallysh to Firebase Hosting

Google sign-in will not work from a `file:///` address. Publish this folder, then open `https://rallysh.web.app`.

1. Install Node.js LTS from https://nodejs.org.
2. Open Command Prompt in this folder.
3. Run `npm install -g firebase-tools`.
4. Run `firebase login` and choose the Google account that owns the Rallysh Firebase project.
5. Run `firebase deploy --only hosting`.

Firebase will print the public Rallysh URL. Use that HTTPS address for browser testing and Google sign-in. Do not use the local `index.html` file for Google login.
